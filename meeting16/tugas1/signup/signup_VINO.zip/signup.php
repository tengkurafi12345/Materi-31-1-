<?php
include 'koneksi.php';

$USERNAME=$_POST["USERNAME"];
$PASSWORD=$_POST["PASSWORD"];
$RE_ENTER_PASSWORD=$_POST["RE-ENTER-PASSWORD"];
$EMAIL=$_POST["EMAIL"];

mysqli_query($koneksi,"INSERT INTO account VALUES('','USERNAME','PASSWORD','RE-ENTER-PASSWORD','EMAIL' ) ");
header("location:index.php");

?>