<?php
$SERVER="localhost";
$USERNAME="root";
$PASSWORD="";
$DATABASE="perfet_world";

$koneksi=mysqli_connect('localhost','root','','perfect_world');

if(mysqli_connect_errno()){
    echo "koneksi gagal";
}